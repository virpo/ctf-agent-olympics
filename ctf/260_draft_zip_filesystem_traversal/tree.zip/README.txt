Not every keep-looking file is useful. Pattern matters.
